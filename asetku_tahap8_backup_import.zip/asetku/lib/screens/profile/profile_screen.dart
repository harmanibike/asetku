import 'package:flutter/material.dart';

import '../../core/backup/backup_service.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  Future<void> _export(BuildContext context) async {
    try {
      final path = await BackupService.instance.exportBackup();
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(path == null ? 'Penyimpanan backup dibatalkan.' : 'Backup berhasil disimpan.')),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Backup gagal: $e')));
    }
  }

  Future<void> _import(BuildContext context) async {
    try {
      final file = await BackupService.instance.pickBackupFile();
      if (file == null) return;
      final bytes = file.bytes;
      if (bytes == null) throw Exception('File tidak dapat dibaca. Silakan pilih ulang.');
      if (!context.mounted) return;
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Pulihkan data?'),
          content: const Text(
            'Data ASETKU saat ini akan diganti dengan isi file backup. '
            'Sebelum pemulihan, aplikasi akan membuat backup otomatis dari data saat ini. '
            'Pastikan Anda memilih file yang benar.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Ya, pulihkan')),
          ],
        ),
      );
      if (confirmed != true || !context.mounted) return;
      final safetyPath = await BackupService.instance.importBackup(bytes);
      if (!context.mounted) return;
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Pemulihan berhasil'),
          content: Text('Data berhasil dipulihkan.\n\nBackup otomatis data sebelumnya tersimpan di:\n$safetyPath'),
          actions: [FilledButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Selesai'))],
        ),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Import gagal: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profil & Pengaturan')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: ListTile(
              leading: CircleAvatar(child: Icon(Icons.account_balance_wallet_outlined)),
              title: Text('ASETKU', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('Personal Wealth Tracker'),
            ),
          ),
          const SizedBox(height: 18),
          const Text('PENGELOLAAN DATA', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.backup_outlined),
                  title: const Text('Backup Data'),
                  subtitle: const Text('Simpan seluruh aset, transaksi, riwayat harga, dan kurs ke file JSON'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _export(context),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.restore_outlined),
                  title: const Text('Import / Pulihkan Data'),
                  subtitle: const Text('Pulihkan data dari file backup ASETKU'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _import(context),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                'Keamanan: file backup diperiksa identitas aplikasi dan versi formatnya. '
                'Sebelum data dipulihkan, ASETKU membuat salinan otomatis data saat ini. '
                'Pemulihan hanya berjalan setelah Anda menyetujuinya.',
                style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.5),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
