import 'package:flutter/material.dart';

import '../../core/database/database_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/asset.dart';
import '../assets/asset_management_screen.dart';
import '../prices/exchange_rate_screen.dart';
import '../prices/market_price_screen.dart';
import '../profile/profile_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<({List<Asset> assets, Map<String, Map<String, Object?>> rates})> _dashboardFuture;

  @override
  void initState() {
    super.initState();
    _loadAssets();
  }

  Future<({List<Asset> assets, Map<String, Map<String, Object?>> rates})> _loadDashboardData() async {
    final assetsFuture = DatabaseService.instance.getAssets();
    final ratesFuture = DatabaseService.instance.getExchangeRates();
    final assets = await assetsFuture;
    final rates = await ratesFuture;
    return (assets: assets, rates: rates);
  }

  void _loadAssets() {
    _dashboardFuture = _loadDashboardData();
  }

  Future<void> _refresh() async {
    setState(_loadAssets);
    await _dashboardFuture;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('ASETKU', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2)),
            Text('Personal Wealth Tracker', style: TextStyle(fontSize: 11, color: Colors.black54)),
          ],
        ),
        actions: [
          IconButton(tooltip: 'Kurs mata uang', onPressed: () async { await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ExchangeRateScreen())); if (mounted) _refresh(); }, icon: const Icon(Icons.currency_exchange_outlined)),
          IconButton(tooltip: 'Harga pasar', onPressed: () async { await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MarketPriceScreen())); if (mounted) _refresh(); }, icon: const Icon(Icons.price_change_outlined)),
          IconButton(
            tooltip: 'Muat ulang',
            onPressed: _refresh,
            icon: const Icon(Icons.refresh_rounded),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(
        child: FutureBuilder<({List<Asset> assets, Map<String, Map<String, Object?>> rates})>(
          future: _dashboardFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return _ErrorView(message: 'Data aset gagal dibaca.\n${snapshot.error}', onRetry: _refresh);
            }
            final data = snapshot.data!;
            final assets = data.assets;
            return RefreshIndicator(
              onRefresh: _refresh,
              child: _DashboardContent(assets: assets, exchangeRates: data.rates),
            );
          },
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: (index) async {
          if (index == 1) {
            await Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const AssetManagementScreen()),
            );
            if (mounted) _refresh();
          } else if (index == 4) {
            await Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const ProfileScreen()),
            );
            if (mounted) _refresh();
          } else if (index != 0) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Menu ini akan diaktifkan pada tahap berikutnya.')),
            );
          }
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.pie_chart_outline), label: 'Aset'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), label: 'Transaksi'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'Analisis'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profil'),
        ],
      ),
    );
  }
}

class _DashboardContent extends StatelessWidget {
  const _DashboardContent({required this.assets, required this.exchangeRates});
  final List<Asset> assets;
  final Map<String, Map<String, Object?>> exchangeRates;

  @override
  Widget build(BuildContext context) {
    final unconvertedAssets = <Asset>[];
    double invested = 0;
    double marketValue = 0;
    final grouped = <String, double>{};
    for (final asset in assets) {
      final currency = asset.currency.toUpperCase();
      final rate = currency == 'IDR' ? 1.0 : (exchangeRates[currency]?['rate_to_idr'] as num?)?.toDouble();
      if (rate == null || rate <= 0) {
        unconvertedAssets.add(asset);
        continue;
      }
      final assetInvested = asset.investedValue * rate;
      final assetMarket = asset.marketValue * rate;
      invested += assetInvested;
      marketValue += assetMarket;
      grouped.update(asset.category, (value) => value + assetMarket, ifAbsent: () => assetMarket);
    }
    final profitLoss = marketValue - invested;
    final returnPct = invested == 0 ? 0.0 : profitLoss / invested * 100;
    final foreignAssets = unconvertedAssets.where((asset) => asset.currency.toUpperCase() != 'IDR').toList();

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
      children: [
        _WealthCard(marketValue: marketValue, profitLoss: profitLoss, returnPct: returnPct),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(child: _SummaryCard(title: 'Total Modal', value: formatRupiah(invested), icon: Icons.account_balance_wallet_outlined)),
            const SizedBox(width: 12),
            Expanded(child: _SummaryCard(title: 'Nilai Pasar', value: formatRupiah(marketValue), icon: Icons.account_balance_outlined)),
          ],
        ),
        const SizedBox(height: 22),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Portofolio Saya', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.navy)),
            Text('${assets.length} aset', style: const TextStyle(color: Colors.black54, fontSize: 12)),
          ],
        ),
        const SizedBox(height: 8),
        if (assets.isEmpty)
          const _EmptyPortfolio()
        else ...[
          if (grouped.isEmpty)
            const _InfoCard(message: 'Belum ada aset dengan kurs yang tersedia. Atur kurs mata uang melalui ikon pertukaran di bagian atas.'),
          ...grouped.entries.map((entry) => _CategoryRow(category: entry.key, value: entry.value)),
          if (foreignAssets.isNotEmpty) ...[
            const SizedBox(height: 12),
            const Text('Aset Mata Uang Asing', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppTheme.navy)),
            const SizedBox(height: 6),
            ..._groupForeignAssets(foreignAssets).entries.map(
              (entry) => _ForeignCurrencyRow(currency: entry.key, count: entry.value.$1, value: entry.value.$2),
            ),
            const _InfoCard(message: 'Aset di atas belum masuk total Rupiah karena kursnya belum diatur. Tambahkan kurs pada menu Kurs Mata Uang.'),
          ],
        ],
        const SizedBox(height: 22),
        const Text('Aset Terakhir', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.navy)),
        const SizedBox(height: 8),
        if (assets.isEmpty)
          const _InfoCard(message: 'Aset yang nanti Anda tambahkan akan muncul di bagian ini.')
        else
          ...assets.take(5).map((asset) => _AssetTile(asset: asset)),
      ],
    );
  }

  Map<String, (int, double)> _groupForeignAssets(List<Asset> assets) {
    final result = <String, (int, double)>{};
    for (final asset in assets) {
      final currency = asset.currency.toUpperCase();
      final current = result[currency] ?? (0, 0.0);
      result[currency] = (current.$1 + 1, current.$2 + asset.marketValue);
    }
    return result;
  }
}

class _WealthCard extends StatelessWidget {
  const _WealthCard({required this.marketValue, required this.profitLoss, required this.returnPct});
  final double marketValue;
  final double profitLoss;
  final double returnPct;

  @override
  Widget build(BuildContext context) {
    final positive = profitLoss >= 0;
    final resultColor = positive ? const Color(0xFF70D6A5) : const Color(0xFFFFA69B);
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [AppTheme.navy, Color(0xFF263F60)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('TOTAL NILAI ASET (IDR)', style: TextStyle(color: Color(0xFFCAD4E1), fontSize: 11, letterSpacing: 1.1)),
        const SizedBox(height: 9),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(formatRupiah(marketValue), style: const TextStyle(color: Colors.white, fontSize: 29, fontWeight: FontWeight.bold)),
        ),
        const SizedBox(height: 15),
        Row(children: [
          Icon(positive ? Icons.trending_up_rounded : Icons.trending_down_rounded, color: resultColor, size: 18),
          const SizedBox(width: 5),
          Flexible(child: Text('${positive ? '+' : ''}${formatRupiah(profitLoss)} (${returnPct.toStringAsFixed(2)}%)', style: TextStyle(color: resultColor, fontWeight: FontWeight.w700))),
        ]),
        const SizedBox(height: 5),
        const Text('Keuntungan / kerugian belum terealisasi', style: TextStyle(color: Color(0xFFCAD4E1), fontSize: 10)),
      ]),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, color: AppTheme.gold),
            const SizedBox(height: 12),
            Text(title, style: const TextStyle(color: Colors.black54, fontSize: 11)),
            const SizedBox(height: 4),
            FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppTheme.navy))),
          ]),
        ),
      );
}

class _CategoryRow extends StatelessWidget {
  const _CategoryRow({required this.category, required this.value});
  final String category;
  final double value;

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          leading: const CircleAvatar(backgroundColor: Color(0xFFEAF0F7), child: Icon(Icons.pie_chart_outline_rounded, color: AppTheme.navy)),
          title: Text(category, style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.navy)),
          trailing: Text(formatRupiah(value), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
        ),
      );
}

class _AssetTile extends StatelessWidget {
  const _AssetTile({required this.asset});
  final Asset asset;

  @override
  Widget build(BuildContext context) {
    final value = asset.marketValue;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: const Color(0xFFEAF0F7), child: Text(asset.name.isEmpty ? '?' : asset.name[0].toUpperCase(), style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.navy))),
        title: Text(asset.name, style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.navy)),
        subtitle: Text('${asset.category} • ${asset.quantity} ${asset.symbol ?? ''}'.trim(), style: const TextStyle(fontSize: 11)),
        trailing: Text(asset.currency.toUpperCase() == 'IDR' ? formatRupiah(value) : '${asset.currency.toUpperCase()} ${value.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
      ),
    );
  }
}

class _ForeignCurrencyRow extends StatelessWidget {
  const _ForeignCurrencyRow({required this.currency, required this.count, required this.value});
  final String currency;
  final int count;
  final double value;

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          leading: const CircleAvatar(backgroundColor: Color(0xFFFFF4DF), child: Icon(Icons.currency_exchange_rounded, color: Color(0xFF9A742E))),
          title: Text(currency, style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.navy)),
          subtitle: Text('$count aset'),
          trailing: Text('$currency ${value.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
        ),
      );
}

class _EmptyPortfolio extends StatelessWidget {
  const _EmptyPortfolio();

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 28),
          child: Column(children: [
            const Icon(Icons.account_balance_wallet_outlined, size: 42, color: AppTheme.gold),
            const SizedBox(height: 10),
            const Text('Portofolio masih kosong', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy)),
            const SizedBox(height: 5),
            const Text('Mulai dengan mencatat aset pertama Anda. Fitur tambah aset akan hadir pada tahap berikutnya.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 12)),
          ]),
        ),
      );
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(padding: const EdgeInsets.all(14), child: Text(message, style: const TextStyle(color: Colors.black54, fontSize: 12))),
      );
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 42),
            const SizedBox(height: 12),
            const Text('Tidak dapat memuat dashboard', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Colors.black54)),
            const SizedBox(height: 12),
            FilledButton(onPressed: onRetry, child: const Text('Coba lagi')),
          ]),
        ),
      );
}
