import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../database/database_service.dart';

class BackupService {
  BackupService._();
  static final BackupService instance = BackupService._();

  static const appId = 'com.asetku.v2.asetku';
  static const schemaVersion = 1;
  static const _tables = <String>[
    'assets',
    'transactions',
    'price_history',
    'asset_market_links',
    'asset_market_prices',
    'exchange_rates',
  ];

  Future<Map<String, Object?>> createBackupData() async {
    final db = await DatabaseService.instance.database;
    final data = <String, Object?>{};
    for (final table in _tables) {
      data[table] = await db.query(table);
    }
    return {
      'appId': appId,
      'schemaVersion': schemaVersion,
      'createdAt': DateTime.now().toIso8601String(),
      'data': data,
    };
  }

  Future<String?> exportBackup() async {
    final backup = await createBackupData();
    final bytes = utf8.encode(const JsonEncoder.withIndent('  ').convert(backup));
    return FilePicker.platform.saveFile(
      dialogTitle: 'Simpan backup ASETKU',
      fileName: 'asetku_backup_${DateTime.now().toIso8601String().replaceAll(':', '-')}.json',
      type: FileType.custom,
      allowedExtensions: ['json'],
      bytes: bytes,
    );
  }

  Future<Map<String, Object?>> _readAndValidate(List<int> bytes) async {
    final decoded = jsonDecode(utf8.decode(bytes));
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Format file backup tidak valid.');
    }
    if (decoded['appId'] != appId) {
      throw const FormatException('File ini bukan backup dari aplikasi ASETKU yang sesuai.');
    }
    if (decoded['schemaVersion'] != schemaVersion) {
      throw FormatException('Versi format backup tidak didukung: ${decoded['schemaVersion']}.');
    }
    final data = decoded['data'];
    if (data is! Map<String, dynamic>) {
      throw const FormatException('Bagian data backup tidak ditemukan.');
    }
    for (final table in _tables) {
      if (data[table] is! List) {
        throw FormatException('Data tabel $table tidak lengkap.');
      }
    }
    return decoded;
  }

  Future<String> _createSafetyBackup() async {
    final directory = await getApplicationDocumentsDirectory();
    final folder = Directory('${directory.path}/automatic_backups');
    await folder.create(recursive: true);
    final name = 'before_restore_${DateTime.now().toIso8601String().replaceAll(':', '-')}.json';
    final file = File('${folder.path}/$name');
    final backup = await createBackupData();
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(backup), flush: true);
    return file.path;
  }

  Future<String> importBackup(List<int> bytes) async {
    final backup = await _readAndValidate(bytes);
    final safetyPath = await _createSafetyBackup();
    final data = backup['data'] as Map<String, dynamic>;
    final db = await DatabaseService.instance.database;

    await db.transaction((txn) async {
      // Delete child rows before parent rows to respect foreign keys.
      for (final table in [
        'transactions',
        'price_history',
        'asset_market_links',
        'asset_market_prices',
        'assets',
        'exchange_rates',
      ]) {
        await txn.delete(table);
      }

      // Insert parent records first, retaining primary keys and relationships.
      for (final table in [
        'assets',
        'transactions',
        'price_history',
        'asset_market_links',
        'asset_market_prices',
        'exchange_rates',
      ]) {
        final rows = (data[table] as List).cast<Map<String, dynamic>>();
        for (final row in rows) {
          await txn.insert(table, Map<String, Object?>.from(row));
        }
      }
    });
    return safetyPath;
  }

  Future<PlatformFile?> pickBackupFile() async {
    final result = await FilePicker.platform.pickFiles(
      dialogTitle: 'Pilih file backup ASETKU',
      type: FileType.custom,
      allowedExtensions: ['json'],
      withData: true,
      allowMultiple: false,
    );
    if (result == null || result.files.isEmpty) return null;
    return result.files.single;
  }
}
