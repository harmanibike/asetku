import 'package:flutter/material.dart';

import '../../core/backup/backup_service.dart';
import '../../core/theme/app_theme.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  bool _busy = false;

  Future<void> _export() async {
    setState(() => _busy = true);
    try {
      await BackupService.instance.exportAndShare();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('File backup dibuat. Silakan simpan melalui menu berbagi.')),
        );
      }
    } catch (error) {
      _showError('Gagal membuat backup: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _import() async {
    try {
      final file = await BackupService.instance.pickBackupFile();
      if (file == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Pemilihan file dibatalkan.')),
          );
        }
        return;
      }
      await BackupService.instance.validateBackupFile(file);
      if (!mounted) return;

      final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Konfirmasi pemulihan data'),
          content: const Text(
            'Import akan mengganti data Asetku saat ini dengan isi file backup. '
            'Data saat ini akan disalin otomatis terlebih dahulu. Lanjutkan?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Pulihkan data'),
            ),
          ],
        ),
      );
      if (confirmed != true || !mounted) return;

      setState(() => _busy = true);
      final message = await BackupService.instance.restoreFromFile(file);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(message)),
        );
      }
    } catch (error) {
      _showError('Import gagal: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red.shade700),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Backup & Import Data',
          style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.shield_outlined, size: 34, color: AppTheme.gold),
                  SizedBox(height: 10),
                  Text(
                    'Amankan data Asetku',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.navy,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'Backup mencakup aset, transaksi, riwayat harga, tautan harga pasar, '
                    'harga pasar emas, dan kurs mata uang. File disimpan dalam format JSON.',
                    style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.5),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.upload_file_outlined, color: AppTheme.navy),
              title: const Text('Backup data'),
              subtitle: const Text('Buat file JSON dan bagikan/simpan ke lokasi aman'),
              trailing: const Icon(Icons.chevron_right),
              onTap: _busy ? null : _export,
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.restore_outlined, color: AppTheme.navy),
              title: const Text('Import / pulihkan data'),
              subtitle: const Text('Pilih file backup JSON dari perangkat'),
              trailing: const Icon(Icons.chevron_right),
              onTap: _busy ? null : _import,
            ),
          ),
          if (_busy) const Padding(
            padding: EdgeInsets.all(18),
            child: Center(child: CircularProgressIndicator()),
          ),
          const SizedBox(height: 12),
          const Text(
            'Penting: simpan file backup di tempat terpisah, misalnya Google Drive atau penyimpanan lain. '
            'Jangan menghapus aplikasi sebelum memastikan backup berhasil disimpan.',
            style: TextStyle(fontSize: 11, color: Colors.black54, height: 1.5),
          ),
        ],
      ),
    );
  }
}
