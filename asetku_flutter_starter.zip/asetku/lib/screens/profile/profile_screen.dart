import 'package:flutter/material.dart';

import '../../core/backup/backup_service.dart';
import '../../core/theme/app_theme.dart';
import 'backup_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Profil',
          style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Color(0xFFEAF0F7),
                child: Icon(Icons.person_outline, color: AppTheme.navy),
              ),
              title: Text('Asetku', style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('Personal Wealth Tracker'),
            ),
          ),
          const SizedBox(height: 12),
          const Padding(
            padding: EdgeInsets.fromLTRB(4, 8, 4, 4),
            child: Text(
              'PENGATURAN',
              style: TextStyle(
                color: AppTheme.navy,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
              ),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.settings_outlined, color: AppTheme.navy),
              title: const Text('Pengaturan'),
              subtitle: const Text('Backup dan import data aplikasi'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const BackupScreen()),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Center(
            child: Text(
              'Asetku • Backup lokal untuk menjaga keamanan data Anda',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: Colors.black54),
            ),
          ),
        ],
      ),
    );
  }
}
