import 'package:flutter/material.dart';

import '../../core/database/database_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/asset.dart';
import '../../models/investment_transaction.dart';

class AssetTransactionsScreen extends StatefulWidget {
  const AssetTransactionsScreen({super.key, required this.asset});
  final Asset asset;

  @override
  State<AssetTransactionsScreen> createState() => _AssetTransactionsScreenState();
}

class _AssetTransactionsScreenState extends State<AssetTransactionsScreen> {
  late Future<List<Map<String, Object?>>> _future;
  late Asset _asset;
  void _load() => _future = DatabaseService.instance.getTransactions(widget.asset.id!);

  @override
  void initState() {
    super.initState();
    _asset = widget.asset;
    _load();
  }

  Future<void> _add() async {
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _TransactionForm(asset: widget.asset),
    );
    if (result == true && mounted) {
      final assets = await DatabaseService.instance.getAssets();
      final updated = assets.where((item) => item.id == widget.asset.id);
      if (updated.isNotEmpty) _asset = updated.first;
      setState(_load);
    }
  }

  String _typeName(String type) => switch (type) {
        'BUY' => 'Beli',
        'SELL' => 'Jual',
        'DIVIDEND' => 'Dividen',
        'INTEREST' => 'Bunga',
        'COUPON' => 'Kupon obligasi',
        _ => type,
      };

  String _money(double value) => _asset.currency == 'IDR'
      ? formatRupiah(value)
      : '${_asset.currency} ${value.toStringAsFixed(2)}';

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Riwayat Transaksi', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy)),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _add,
          icon: const Icon(Icons.add),
          label: const Text('Catat Transaksi'),
        ),
        body: FutureBuilder<List<Map<String, Object?>>>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
            if (snapshot.hasError) return Center(child: Text('Gagal memuat transaksi: ${snapshot.error}'));
            final transactions = (snapshot.data ?? []).map(InvestmentTransaction.fromMap).toList();
            final realized = transactions.fold<double>(0, (sum, item) => sum + item.realizedProfit);
            return RefreshIndicator(
              onRefresh: () async => setState(_load),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(_asset.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17, color: AppTheme.navy)),
                        const SizedBox(height: 8),
                        Text('Unit saat ini: ${_asset.quantity} ${_asset.currency}'),
                        const SizedBox(height: 4),
                        Text('Laba/rugi terealisasi: ${_money(realized)}', style: TextStyle(fontWeight: FontWeight.w700, color: realized >= 0 ? Colors.green.shade700 : Colors.red.shade700)),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (transactions.isEmpty)
                    const Padding(padding: EdgeInsets.all(30), child: Text('Belum ada transaksi. Tekan Catat Transaksi untuk memulai.', textAlign: TextAlign.center))
                  else
                    ...transactions.map((tx) {
                      final isIncome = ['DIVIDEND', 'INTEREST', 'COUPON'].contains(tx.type);
                      final value = tx.grossValue;
                      final date = '${tx.transactionDate.day.toString().padLeft(2, '0')}/${tx.transactionDate.month.toString().padLeft(2, '0')}/${tx.transactionDate.year}';
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: tx.type == 'SELL' ? const Color(0xFFFFE9E7) : const Color(0xFFE8F3EC),
                            child: Icon(tx.type == 'SELL' ? Icons.south_east : (tx.type == 'BUY' ? Icons.north_west : Icons.payments_outlined), color: tx.type == 'SELL' ? Colors.red : Colors.green),
                          ),
                          title: Text(_typeName(tx.type), style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text('$date${tx.notes == null || tx.notes!.isEmpty ? '' : '\n${tx.notes}'}${tx.type == 'SELL' ? '\nLaba/rugi: ${_money(tx.realizedProfit)}' : ''}'),
                          isThreeLine: tx.notes != null || tx.type == 'SELL',
                          trailing: Text(_money(value), textAlign: TextAlign.end, style: TextStyle(fontWeight: FontWeight.w700, color: isIncome || tx.type == 'SELL' ? Colors.green.shade700 : AppTheme.navy)),
                        ),
                      );
                    }),
                  const SizedBox(height: 10),
                  const Text('Catatan: biaya dan pajak pembelian masuk ke harga pokok rata-rata. Laba/rugi penjualan dihitung dari hasil bersih penjualan dikurangi harga pokok unit yang dijual.', style: TextStyle(fontSize: 11, color: Colors.black54)),
                ],
              ),
            );
          },
        ),
      );
}

class _TransactionForm extends StatefulWidget {
  const _TransactionForm({required this.asset});
  final Asset asset;

  @override
  State<_TransactionForm> createState() => _TransactionFormState();
}

class _TransactionFormState extends State<_TransactionForm> {
  final _formKey = GlobalKey<FormState>();
  final _quantity = TextEditingController();
  final _price = TextEditingController();
  final _fee = TextEditingController(text: '0');
  final _tax = TextEditingController(text: '0');
  final _notes = TextEditingController();
  String _type = 'BUY';
  DateTime _date = DateTime.now();
  bool _saving = false;

  bool get _isIncome => ['DIVIDEND', 'INTEREST', 'COUPON'].contains(_type);
  bool get _hasUnits => _type == 'BUY' || _type == 'SELL';

  @override
  void dispose() {
    _quantity.dispose();
    _price.dispose();
    _fee.dispose();
    _tax.dispose();
    _notes.dispose();
    super.dispose();
  }

  double _number(String value) => double.parse(value.trim().replaceAll(',', '.'));
  String? _validate(String? value, {bool required = true}) {
    if (value == null || value.trim().isEmpty) return required ? 'Wajib diisi' : null;
    final number = double.tryParse(value.trim().replaceAll(',', '.'));
    if (number == null || !number.isFinite || number < 0) return 'Masukkan angka nol atau lebih';
    if (required && number == 0) return 'Nilai harus lebih dari nol';
    return null;
  }

  Future<void> _pickDate() async {
    final selected = await showDatePicker(context: context, initialDate: _date, firstDate: DateTime(2000), lastDate: DateTime.now().add(const Duration(days: 1)));
    if (selected != null) setState(() => _date = selected);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await DatabaseService.instance.addInvestmentTransaction(
        assetId: widget.asset.id!,
        type: _type,
        quantity: _isIncome ? 1 : _number(_quantity.text),
        price: _number(_price.text),
        fee: _isIncome ? 0 : (_fee.text.trim().isEmpty ? 0 : _number(_fee.text)),
        tax: _isIncome ? 0 : (_tax.text.trim().isEmpty ? 0 : _number(_tax.text)),
        transactionDate: _date,
        notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) {
        setState(() => _saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Transaksi gagal disimpan: $error')));
      }
    }
  }

  InputDecoration _dec(String label) => InputDecoration(labelText: label);
  @override
  Widget build(BuildContext context) {
    final types = <String, String>{'BUY': 'Beli', 'SELL': 'Jual', 'DIVIDEND': 'Dividen', 'INTEREST': 'Bunga', 'COUPON': 'Kupon obligasi'};
    return Padding(
      padding: EdgeInsets.only(left: 18, right: 18, top: 18, bottom: MediaQuery.of(context).viewInsets.bottom + 20),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
            const Text('Catat Transaksi', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppTheme.navy)),
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(value: _type, decoration: _dec('Jenis transaksi'), items: types.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value))).toList(), onChanged: (value) => setState(() => _type = value ?? 'BUY')),
            const SizedBox(height: 10),
            if (_hasUnits) ...[
              TextFormField(controller: _quantity, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: _dec('Jumlah unit'), validator: (v) => _validate(v)),
              const SizedBox(height: 10),
            ],
            TextFormField(controller: _price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: _dec(_isIncome ? 'Nominal pendapatan (${widget.asset.currency})' : 'Harga per unit (${widget.asset.currency})'), validator: (v) => _validate(v)),
            if (!_isIncome) ...[
              const SizedBox(height: 10),
              TextFormField(controller: _fee, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: _dec('Biaya transaksi (${widget.asset.currency})'), validator: (v) => _validate(v, required: false)),
              const SizedBox(height: 10),
              TextFormField(controller: _tax, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: _dec('Pajak (${widget.asset.currency})'), validator: (v) => _validate(v, required: false)),
            ],
            const SizedBox(height: 10),
            OutlinedButton.icon(onPressed: _pickDate, icon: const Icon(Icons.calendar_month), label: Text('Tanggal: ${_date.day.toString().padLeft(2, '0')}/${_date.month.toString().padLeft(2, '0')}/${_date.year}')),
            const SizedBox(height: 10),
            TextFormField(controller: _notes, decoration: _dec('Catatan (opsional)'), maxLines: 2),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.save), label: Text(_saving ? 'Menyimpan...' : 'Simpan Transaksi')),
          ]),
        ),
      ),
    );
  }
}
