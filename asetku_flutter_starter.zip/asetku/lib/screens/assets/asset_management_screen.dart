import 'package:flutter/material.dart';
import '../../core/database/database_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/asset.dart';
import 'asset_transactions_screen.dart';

class AssetManagementScreen extends StatefulWidget {
  const AssetManagementScreen({super.key});
  @override
  State<AssetManagementScreen> createState() => _AssetManagementScreenState();
}

class _AssetManagementScreenState extends State<AssetManagementScreen> {
  late Future<List<Asset>> _future;
  void _load() => _future = DatabaseService.instance.getAssets();
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _refresh() async { setState(_load); await _future; }

  Future<void> _form([Asset? asset]) async {
    final result = await Navigator.push<Asset>(context, MaterialPageRoute(builder: (_) => AssetFormScreen(asset: asset)));
    if (result == null || !mounted) return;
    try {
      await DatabaseService.instance.saveAsset(result);
      if (!mounted) return;
      setState(_load);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(asset == null ? 'Aset berhasil ditambahkan.' : 'Aset berhasil diperbarui.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal menyimpan aset: $e')));
    }
  }

  Future<void> _delete(Asset asset) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Hapus aset?'),
      content: Text('Data "${asset.name}" dan transaksi terkait akan dihapus.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hapus'))],
    ));
    if (ok != true || asset.id == null) return;
    await DatabaseService.instance.deleteAsset(asset.id!);
    if (mounted) { setState(_load); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Aset berhasil dihapus.'))); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Kelola Aset', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy))),
    floatingActionButton: FloatingActionButton.extended(onPressed: () => _form(), icon: const Icon(Icons.add), label: const Text('Tambah Aset')),
    body: FutureBuilder<List<Asset>>(future: _future, builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      if (snap.hasError) return Center(child: Text('Gagal membaca aset: ${snap.error}'));
      final assets = snap.data ?? [];
      if (assets.isEmpty) return RefreshIndicator(onRefresh: _refresh, child: ListView(physics: const AlwaysScrollableScrollPhysics(), padding: const EdgeInsets.all(28), children: const [SizedBox(height: 90), Icon(Icons.account_balance_wallet_outlined, size: 64, color: AppTheme.gold), SizedBox(height: 16), Text('Belum ada aset', textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppTheme.navy)), SizedBox(height: 8), Text('Tekan Tambah Aset untuk mulai mencatat investasi atau simpanan Anda.', textAlign: TextAlign.center)]));
      return RefreshIndicator(onRefresh: _refresh, child: ListView.builder(padding: const EdgeInsets.fromLTRB(16, 12, 16, 100), itemCount: assets.length, itemBuilder: (context, i) {
        final a = assets[i];
        final pl = a.unrealizedProfitLoss;
        final plText = a.currency == 'IDR' ? formatRupiah(pl) : '${a.currency} ${pl.toStringAsFixed(2)}';
        final marketText = a.currency == 'IDR' ? formatRupiah(a.marketValue) : '${a.currency} ${a.marketValue.toStringAsFixed(2)}';
        return Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(
          onTap: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => AssetTransactionsScreen(asset: a)));
            if (mounted) setState(_load);
          }, isThreeLine: true,
          leading: CircleAvatar(backgroundColor: const Color(0xFFEAF0F7), child: Text(a.name.isEmpty ? '?' : a.name[0].toUpperCase(), style: const TextStyle(color: AppTheme.navy, fontWeight: FontWeight.bold))),
          title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy)),
          subtitle: Text('${a.category}${a.symbol == null ? '' : ' • ${a.symbol}'}\nJumlah: ${a.quantity} ${a.currency}\nLaba/rugi: $plText', style: TextStyle(height: 1.5, color: pl >= 0 ? Colors.green.shade700 : Colors.red.shade700, fontSize: 11)),
          trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(marketText, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)), PopupMenuButton<String>(padding: EdgeInsets.zero, onSelected: (v) { if (v == 'edit') _form(a); if (v == 'delete') _delete(a); if (v == 'transactions') { Navigator.push(context, MaterialPageRoute(builder: (_) => AssetTransactionsScreen(asset: a))).then((_) { if (mounted) setState(_load); }); } }, itemBuilder: (_) => const [PopupMenuItem(value: 'transactions', child: Text('Riwayat transaksi')), PopupMenuItem(value: 'edit', child: Text('Edit aset')), PopupMenuItem(value: 'delete', child: Text('Hapus'))])]),
        ));
      }));
    }),
  );
}

class AssetFormScreen extends StatefulWidget {
  const AssetFormScreen({super.key, this.asset});
  final Asset? asset;
  @override
  State<AssetFormScreen> createState() => _AssetFormScreenState();
}

class _AssetFormScreenState extends State<AssetFormScreen> {
  final _key = GlobalKey<FormState>();
  late final TextEditingController _name, _symbol, _qty, _avg, _price, _notes;
  late String _category, _currency;
  static const _categories = ['Saham', 'Reksadana', 'ETF', 'Obligasi / SBN', 'Emas', 'Emas Digital', 'Kripto', 'Deposito', 'Tabungan Bank', 'E-Wallet', 'Properti', 'Lainnya'];
  static const _currencies = ['IDR', 'USD', 'SGD', 'EUR', 'MYR', 'JPY'];
  String _fmt(double? v) => v == null ? '' : (v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toString());
  @override
  void initState() {
    super.initState(); final a = widget.asset;
    _name = TextEditingController(text: a?.name ?? ''); _symbol = TextEditingController(text: a?.symbol ?? '');
    _qty = TextEditingController(text: _fmt(a?.quantity)); _avg = TextEditingController(text: _fmt(a?.averageBuyPrice));
    _price = TextEditingController(text: _fmt(a?.currentPrice)); _notes = TextEditingController(text: a?.notes ?? '');
    _category = _categories.contains(a?.category) ? a!.category : (a?.category ?? _categories.first);
    _currency = _currencies.contains(a?.currency.toUpperCase()) ? a!.currency.toUpperCase() : 'IDR';
  }
  @override
  void dispose() { _name.dispose(); _symbol.dispose(); _qty.dispose(); _avg.dispose(); _price.dispose(); _notes.dispose(); super.dispose(); }
  String? _validate(String? v) { if (v == null || v.trim().isEmpty) return 'Wajib diisi'; final n = double.tryParse(v.trim().replaceAll(',', '.')); return n == null || !n.isFinite || n < 0 ? 'Masukkan angka nol atau lebih' : null; }
  double _num(String v) => double.parse(v.trim().replaceAll(',', '.'));
  void _save() {
    if (!_key.currentState!.validate()) return; final old = widget.asset;
    Navigator.pop(context, Asset(id: old?.id, name: _name.text.trim(), category: _category, symbol: _symbol.text.trim().isEmpty ? null : _symbol.text.trim().toUpperCase(), currency: _currency, quantity: _num(_qty.text), averageBuyPrice: _num(_avg.text), currentPrice: _num(_price.text), notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(), createdAt: old?.createdAt));
  }
  InputDecoration _dec(String label, {String? hint}) => InputDecoration(labelText: label, hintText: hint);
  @override
  Widget build(BuildContext context) {
    final editing = widget.asset != null;
    return Scaffold(appBar: AppBar(title: Text(editing ? 'Edit Aset' : 'Tambah Aset', style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy))), body: Form(key: _key, child: ListView(padding: const EdgeInsets.fromLTRB(18, 12, 18, 30), children: [
      const Text('Informasi Aset', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.navy)), const SizedBox(height: 12),
      TextFormField(controller: _name, textCapitalization: TextCapitalization.words, decoration: _dec('Nama aset *', hint: 'Contoh: BBCA, Bitcoin, Emas Antam'), validator: (v) => v == null || v.trim().isEmpty ? 'Nama aset wajib diisi' : null), const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: _category, decoration: _dec('Kategori aset'), items: _categories.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => _category = v ?? _categories.first)), const SizedBox(height: 12),
      TextFormField(controller: _symbol, textCapitalization: TextCapitalization.characters, decoration: _dec('Kode / simbol (opsional)', hint: 'BBCA, BTC, GLD')), const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: _currency, decoration: _dec('Mata uang'), items: _currencies.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => _currency = v ?? 'IDR')), const SizedBox(height: 22),
      const Text('Jumlah dan Harga', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.navy)), const SizedBox(height: 12),
      TextFormField(controller: _qty, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: _dec('Jumlah / unit *', hint: '10'), validator: _validate), const SizedBox(height: 12),
      TextFormField(controller: _avg, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: _dec('Harga beli rata-rata per unit *', hint: '9500'), validator: _validate), const SizedBox(height: 12),
      TextFormField(controller: _price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: _dec('Harga saat ini per unit *', hint: '10200'), validator: _validate), const SizedBox(height: 12),
      TextFormField(controller: _notes, maxLines: 3, decoration: _dec('Catatan (opsional)')), const SizedBox(height: 22),
      FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_outlined), label: Text(editing ? 'Simpan Perubahan' : 'Simpan Aset'), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52))), const SizedBox(height: 10),
      const Text('Harga beli rata-rata dan harga saat ini disimpan terpisah. Mengubah harga saat ini tidak mengubah modal beli.', style: TextStyle(fontSize: 11, color: Colors.black54)),
    ])));
  }
}
