import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../../core/database/database_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/asset.dart';
import 'gold_price_screen.dart';

class MarketPriceScreen extends StatefulWidget {
  const MarketPriceScreen({super.key});
  @override
  State<MarketPriceScreen> createState() => _MarketPriceScreenState();
}

class _MarketPriceScreenState extends State<MarketPriceScreen> {
  static const _base = 'https://reksadana.risanb.com';
  final _search = TextEditingController();
  List<Map<String, dynamic>> _funds = [];
  List<Asset> _assets = [];
  List<Map<String, Object?>> _links = [];
  bool _loading = true;
  bool _refreshing = false;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { _search.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final responses = await Future.wait([
        http.get(Uri.parse('$_base/api/funds.json')).timeout(const Duration(seconds: 25)),
        DatabaseService.instance.getAssets(),
        DatabaseService.instance.getLinkedFunds(),
      ]);
      final response = responses[0] as http.Response;
      if (response.statusCode != 200) throw Exception('Server ReksadanaID (${response.statusCode})');
      final decoded = jsonDecode(response.body);
      if (decoded is! List) throw Exception('Format daftar reksadana tidak sesuai.');
      if (!mounted) return;
      setState(() {
        _funds = decoded.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).where((e) => e['id'] != null && e['name'] != null).toList();
        _assets = responses[1] as List<Asset>;
        _links = responses[2] as List<Map<String, Object?>>;
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() { _loading = false; _error = e.toString(); });
    }
  }

  Future<void> _connectFund(Map<String, dynamic> fund) async {
    final eligible = _assets.where((a) => a.category.toLowerCase().contains('reksadana')).toList();
    if (eligible.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tambahkan aset dengan kategori Reksadana terlebih dahulu.')));
      return;
    }
    Asset? selected = eligible.first;
    final confirmed = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialog) => AlertDialog(
      title: const Text('Hubungkan produk reksadana'),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(fund['name'].toString(), style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        DropdownButtonFormField<Asset>(value: selected, isExpanded: true, decoration: const InputDecoration(labelText: 'Pilih aset di ASETKU'), items: eligible.map((a) => DropdownMenuItem(value: a, child: Text(a.name, overflow: TextOverflow.ellipsis))).toList(), onChanged: (v) => setDialog(() => selected = v)),
        const SizedBox(height: 8),
        const Text('NAB terbaru dari ReksadanaID akan memperbarui harga saat ini, bukan harga beli rata-rata.', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Hubungkan'))],
    )));
    if (confirmed != true || selected?.id == null) return;
    await DatabaseService.instance.linkMutualFund(assetId: selected!.id!, fundId: fund['id'].toString(), fundName: fund['name'].toString());
    await _load();
  }

  Future<void> _refreshLinked() async {
    if (_links.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Belum ada produk reksadana yang dihubungkan.')));
      return;
    }
    setState(() => _refreshing = true);
    var success = 0;
    final errors = <String>[];
    try {
      final catalogResponse = await http.get(Uri.parse('$_base/api/funds.json')).timeout(const Duration(seconds: 25));
      if (catalogResponse.statusCode != 200) throw Exception('Server ReksadanaID (${catalogResponse.statusCode})');
      final catalog = (jsonDecode(catalogResponse.body) as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      final byId = {for (final f in catalog) f['id'].toString(): f};
      for (final link in _links) {
        try {
          final fund = byId[link['product_id'].toString()];
          final nav = (fund?['nav'] as num?)?.toDouble();
          final navDate = fund?['nav_date']?.toString();
          final assetId = link['asset_id'] as int?;
          if (nav == null || nav <= 0 || navDate == null || assetId == null) throw Exception('NAB belum tersedia di sumber');
          await DatabaseService.instance.updateFundNav(assetId: assetId, nav: nav, navDate: navDate, updatedAt: DateTime.now().toIso8601String());
          success++;
        } catch (e) { errors.add('${link['product_name']}: $e'); }
      }
    } catch (e) {
      errors.add('Gagal mengambil katalog ReksadanaID: $e');
    }
    await _load();
    if (!mounted) return;
    setState(() => _refreshing = false);
    final msg = '$success dari ${_links.length} harga berhasil diperbarui${errors.isEmpty ? '.' : '. ${errors.length} gagal.'}';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 5)));
  }

  @override
  Widget build(BuildContext context) {
    final q = _search.text.trim().toLowerCase();
    final visible = _funds.where((f) => '${f['name']} ${f['manager'] ?? ''} ${f['type'] ?? ''} ${f['id']}'.toLowerCase().contains(q)).take(100).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Harga Pasar', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy)), actions: [IconButton(onPressed: _refreshing ? null : _refreshLinked, tooltip: 'Perbarui NAB', icon: _refreshing ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.sync))]),
      body: _loading ? const Center(child: CircularProgressIndicator()) : _error != null ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.cloud_off, size: 48), const SizedBox(height: 12), Text('Gagal memuat data ReksadanaID\n$_error', textAlign: TextAlign.center), const SizedBox(height: 12), FilledButton(onPressed: _load, child: const Text('Coba Lagi'))]))) : RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(16), children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'REKSADANA INDONESIA',
                  style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy),
                ),
                const SizedBox(height: 6),
                Text(
                  '${_funds.length} produk tersedia • Sumber: ReksadanaID',
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
                const SizedBox(height: 8),
                const Text(
                  'NAB diperbarui mengikuti publikasi data sumber, umumnya pada hari bursa. Ini bukan harga real-time.',
                  style: TextStyle(fontSize: 11, color: Colors.black54),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const GoldPriceScreen()),
          ),
          icon: const Icon(Icons.workspace_premium_outlined),
          label: const Text('Kelola harga emas & emas digital'),
        ),
        const SizedBox(height: 12),
        const Text('Produk yang terhubung', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.navy)),
        _links.isEmpty
            ? const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text(
                  'Belum ada. Cari produk di bawah lalu hubungkan ke aset Reksadana Anda.',
                  style: TextStyle(color: Colors.black54, fontSize: 12),
                ),
              )
            : Column(
                children: _links.map((link) {
                  final currentPrice =
                      (link['current_price'] as num?)?.toStringAsFixed(4) ?? '-';
                  final productName =
                      link['product_name']?.toString() ?? 'Produk reksadana';
                  final assetName = link['asset_name']?.toString() ?? '-';
                  final navDate =
                      link['nav_date']?.toString() ?? 'belum diperbarui';
                  final updatedAt = link['updated_at']?.toString() ?? 'belum pernah';
                  return Card(
                    child: ListTile(
                      leading: const Icon(Icons.show_chart, color: AppTheme.gold),
                      title: Text(
                        productName,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      subtitle: Text('$assetName • NAB: $navDate\nUpdate: $updatedAt'),
                      trailing: Text(
                        currentPrice,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  );
                }).toList(),
              ),
        FilledButton.icon(onPressed: _refreshing ? null : _refreshLinked, icon: const Icon(Icons.sync), label: Text(_refreshing ? 'Memperbarui...' : 'Perbarui semua NAB')),
        const SizedBox(height: 22),
        const Text('Cari semua reksadana', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.navy)),
        const SizedBox(height: 8),
        TextField(controller: _search, onChanged: (_) => setState(() {}), decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Nama, manajer investasi, jenis, atau ID', suffixIcon: _search.text.isEmpty ? null : IconButton(onPressed: () { _search.clear(); setState(() {}); }, icon: const Icon(Icons.close)))),
        const SizedBox(height: 8),
        Text('${visible.length} hasil ditampilkan (maksimal 100)', style: const TextStyle(fontSize: 11, color: Colors.black54)),
        ...visible.map((f) { final nav = (f['nav'] as num?)?.toDouble(); return Card(margin: const EdgeInsets.only(bottom: 7), child: ListTile(isThreeLine: true, title: Text(f['name'].toString(), style: const TextStyle(fontWeight: FontWeight.w700), maxLines: 2, overflow: TextOverflow.ellipsis), subtitle: Text('${f['type'] ?? 'Jenis tidak tersedia'} • ${f['manager'] ?? 'MI tidak tersedia'}\nNAB ${nav == null ? '-' : formatRupiah(nav)} • ${f['nav_date'] ?? 'tanggal tidak tersedia'}', style: const TextStyle(fontSize: 11, height: 1.4)), trailing: IconButton(tooltip: 'Hubungkan ke aset', icon: const Icon(Icons.add_circle_outline, color: AppTheme.navy), onPressed: () => _connectFund(f)))); }),
      ])),
    );
  }
}
