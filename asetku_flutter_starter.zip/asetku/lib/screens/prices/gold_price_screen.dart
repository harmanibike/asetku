import 'package:flutter/material.dart';

import '../../core/database/database_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/asset.dart';

class GoldPriceScreen extends StatefulWidget {
  const GoldPriceScreen({super.key});

  @override
  State<GoldPriceScreen> createState() => _GoldPriceScreenState();
}

class _GoldPriceScreenState extends State<GoldPriceScreen> {
  static const _providers = <String>[
    'Treasury',
    'Pegadaian',
    'Pluang',
    'IndoGold',
    'Antam',
    'UBS',
    'Galeri 24',
    'Lainnya',
  ];

  late Future<List<Asset>> _assetsFuture;
  late Future<List<Map<String, Object?>>> _pricesFuture;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    _assetsFuture = DatabaseService.instance.getAssets();
    _pricesFuture = DatabaseService.instance.getGoldMarketPrices();
  }

  Future<void> _refresh() async {
    setState(_reload);
    await Future.wait([_assetsFuture, _pricesFuture]);
  }

  Future<void> _editPrice(Asset asset) async {
    final priceController = TextEditingController(
      text: asset.currentPrice > 0 ? asset.currentPrice.toStringAsFixed(0) : '',
    );
    var provider = _providers.first;
    var priceType = 'Harga jual kembali (buyback)';
    final formKey = GlobalKey<FormState>();

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          title: Text('Perbarui harga • ${asset.name}'),
          content: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DropdownButtonFormField<String>(
                    value: provider,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Penyedia / merek'),
                    items: _providers
                        .map((item) => DropdownMenuItem(value: item, child: Text(item)))
                        .toList(),
                    onChanged: (value) {
                      if (value != null) setDialogState(() => provider = value);
                    },
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: priceType,
                    decoration: const InputDecoration(labelText: 'Jenis harga'),
                    items: const [
                      DropdownMenuItem(
                        value: 'Harga jual kembali (buyback)',
                        child: Text('Harga jual kembali (buyback)'),
                      ),
                      DropdownMenuItem(
                        value: 'Harga jual',
                        child: Text('Harga jual'),
                      ),
                    ],
                    onChanged: (value) {
                      if (value != null) setDialogState(() => priceType = value);
                    },
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: priceController,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'Harga per gram (Rp)',
                      prefixText: 'Rp ',
                    ),
                    validator: (value) {
                      final parsed = double.tryParse((value ?? '').replaceAll(',', '.'));
                      if (parsed == null || parsed <= 0) return 'Masukkan harga yang valid';
                      return null;
                    },
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Masukkan harga dari aplikasi atau situs penyedia. Harga ini memperbarui nilai pasar, bukan harga beli historis.',
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Batal'),
            ),
            FilledButton(
              onPressed: () {
                if (formKey.currentState?.validate() ?? false) {
                  Navigator.pop(dialogContext, true);
                }
              },
              child: const Text('Simpan harga'),
            ),
          ],
        ),
      ),
    );

    if (saved == true && asset.id != null) {
      final price = double.parse(priceController.text.trim().replaceAll(',', '.'));
      await DatabaseService.instance.saveGoldMarketPrice(
        assetId: asset.id!,
        provider: provider,
        priceType: priceType,
        price: price,
        sourceLabel: 'Input manual dari pengguna',
        updatedAt: DateTime.now().toIso8601String(),
      );
      if (!mounted) return;
      await _refresh();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Harga emas dan riwayat harga berhasil disimpan.')),
      );
    }
    priceController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Harga Emas', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy)),
      ),
      body: FutureBuilder<List<Asset>>(
        future: _assetsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Gagal membaca aset: ${snapshot.error}'));
          }
          final goldAssets = (snapshot.data ?? <Asset>[])
              .where((asset) => asset.category.toLowerCase().contains('emas'))
              .toList();
          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text('HARGA EMAS & EMAS DIGITAL', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy)),
                        SizedBox(height: 6),
                        Text(
                          'Pilih penyedia dan masukkan harga jual kembali per gram. Integrasi otomatis tiap penyedia akan diaktifkan setelah tersedia sumber data resmi yang dapat diakses.',
                          style: TextStyle(fontSize: 12, color: Colors.black54),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                const Text('Aset emas saya', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.navy)),
                if (goldAssets.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 18),
                    child: Text('Belum ada aset kategori Emas atau Emas Digital. Tambahkan aset terlebih dahulu.'),
                  )
                else
                  ...goldAssets.map((asset) => Card(
                        child: ListTile(
                          leading: const Icon(Icons.workspace_premium_outlined, color: AppTheme.gold),
                          title: Text(asset.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text('Harga saat ini: ${formatRupiah(asset.currentPrice)}'),
                          trailing: IconButton(
                            tooltip: 'Perbarui harga',
                            onPressed: () => _editPrice(asset),
                            icon: const Icon(Icons.edit_outlined),
                          ),
                        ),
                      )),
                const SizedBox(height: 18),
                const Text('Riwayat harga terakhir', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.navy)),
                FutureBuilder<List<Map<String, Object?>>>(
                  future: _pricesFuture,
                  builder: (context, priceSnapshot) {
                    if (priceSnapshot.connectionState == ConnectionState.waiting) {
                      return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
                    }
                    final rows = priceSnapshot.data ?? <Map<String, Object?>>[];
                    if (rows.isEmpty) {
                      return const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Belum ada harga emas yang dicatat.'));
                    }
                    return Column(
                      children: rows.map((row) {
                        final updatedAt = DateTime.tryParse(row['updated_at']?.toString() ?? '')?.toLocal();
                        final dateLabel = updatedAt == null
                            ? '-'
                            : '${updatedAt.day.toString().padLeft(2, '0')}/${updatedAt.month.toString().padLeft(2, '0')}/${updatedAt.year} ${updatedAt.hour.toString().padLeft(2, '0')}:${updatedAt.minute.toString().padLeft(2, '0')}';
                        final price = (row['price'] as num?)?.toDouble() ?? 0;
                        return Card(
                          child: ListTile(
                            title: Text(row['asset_name']?.toString() ?? 'Aset emas'),
                            subtitle: Text('${row['provider']} • ${row['price_type']}\n$dateLabel • ${row['source_label']}'),
                            isThreeLine: true,
                            trailing: Text(formatRupiah(price), style: const TextStyle(fontWeight: FontWeight.w700)),
                          ),
                        );
                      }).toList(),
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
