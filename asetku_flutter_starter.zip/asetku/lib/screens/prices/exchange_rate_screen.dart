import 'package:flutter/material.dart';

import '../../core/database/database_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';

class ExchangeRateScreen extends StatefulWidget {
  const ExchangeRateScreen({super.key});

  @override
  State<ExchangeRateScreen> createState() => _ExchangeRateScreenState();
}

class _ExchangeRateScreenState extends State<ExchangeRateScreen> {
  static const _currencies = ['USD', 'SGD', 'EUR', 'MYR', 'JPY'];
  late Future<Map<String, Map<String, Object?>>> _ratesFuture;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() => _ratesFuture = DatabaseService.instance.getExchangeRates();

  Future<void> _refresh() async {
    setState(_reload);
    await _ratesFuture;
  }

  Future<void> _editRate(String currency, Map<String, Object?>? existing) async {
    final controller = TextEditingController(
      text: (existing?['rate_to_idr'] as num?)?.toString() ?? '',
    );
    final formKey = GlobalKey<FormState>();
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Kurs $currency ke IDR'),
        content: Form(
          key: formKey,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextFormField(
              controller: controller,
              autofocus: true,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(labelText: 'Nilai 1 $currency dalam Rupiah', prefixText: 'Rp '),
              validator: (value) {
                final parsed = double.tryParse((value ?? '').trim().replaceAll(',', '.'));
                if (parsed == null || parsed <= 0) return 'Masukkan kurs yang valid';
                return null;
              },
            ),
            const SizedBox(height: 8),
            const Text('Masukkan kurs yang ingin digunakan. Kurs ini dipakai untuk konversi dashboard, bukan untuk mengubah transaksi historis.', style: TextStyle(fontSize: 12, color: Colors.black54)),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          FilledButton(onPressed: () { if (formKey.currentState?.validate() ?? false) Navigator.pop(ctx, true); }, child: const Text('Simpan')),
        ],
      ),
    );
    if (saved == true) {
      final rate = double.parse(controller.text.trim().replaceAll(',', '.'));
      await DatabaseService.instance.saveExchangeRate(
        currency: currency,
        rateToIdr: rate,
        sourceLabel: 'Input manual pengguna',
        updatedAt: DateTime.now().toIso8601String(),
      );
      if (mounted) {
        await _refresh();
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Kurs $currency berhasil disimpan.')));
      }
    }
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kurs Mata Uang', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy))),
      body: FutureBuilder<Map<String, Map<String, Object?>>>(
        future: _ratesFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text('Gagal membaca kurs: ${snapshot.error}'));
          final rates = snapshot.data ?? <String, Map<String, Object?>>{};
          return RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(padding: const EdgeInsets.all(16), children: [
              Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                Text('KONVERSI ASET KE RUPIAH', style: TextStyle(fontWeight: FontWeight.w800, color: AppTheme.navy)),
                SizedBox(height: 6),
                Text('Atur kurs untuk mata uang asing. Nilai aset dan modal akan dikonversi ke IDR pada dashboard. Kurs yang belum diisi tidak akan ditebak dan asetnya tetap ditampilkan terpisah.', style: TextStyle(fontSize: 12, color: Colors.black54)),
              ]))),
              const SizedBox(height: 8),
              ..._currencies.map((currency) {
                final row = rates[currency];
                final rate = (row?['rate_to_idr'] as num?)?.toDouble();
                final updated = DateTime.tryParse(row?['updated_at']?.toString() ?? '')?.toLocal();
                final date = updated == null ? 'Belum diatur' : 'Update ${updated.day.toString().padLeft(2, '0')}/${updated.month.toString().padLeft(2, '0')}/${updated.year} ${updated.hour.toString().padLeft(2, '0')}:${updated.minute.toString().padLeft(2, '0')}';
                return Card(child: ListTile(
                  leading: CircleAvatar(backgroundColor: const Color(0xFFEAF0F7), child: Text(currency.substring(0, 1), style: const TextStyle(color: AppTheme.navy, fontWeight: FontWeight.bold))),
                  title: Text(currency, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(rate == null ? date : '1 $currency = ${formatRupiah(rate)}\n$date • ${row?['source_label'] ?? 'Sumber tidak diketahui'}'),
                  isThreeLine: rate != null,
                  trailing: IconButton(tooltip: 'Atur kurs', onPressed: () => _editRate(currency, row), icon: const Icon(Icons.edit_outlined)),
                ));
              }),
              const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Catatan: versi ini menggunakan kurs yang Anda masukkan sendiri. Pembaruan kurs otomatis akan ditambahkan setelah sumber data dan ketentuan API terverifikasi.', style: TextStyle(fontSize: 11, color: Colors.black54))),
            ]),
          );
        },
      ),
    );
  }
}
