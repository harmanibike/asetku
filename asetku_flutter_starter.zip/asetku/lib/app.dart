import 'package:flutter/material.dart';
import 'screens/dashboard/dashboard_screen.dart';
import 'core/theme/app_theme.dart';

class AsetkuApp extends StatelessWidget {
  const AsetkuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Asetku',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: const DashboardScreen(),
    );
  }
}
