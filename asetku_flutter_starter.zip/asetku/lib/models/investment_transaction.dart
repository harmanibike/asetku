class InvestmentTransaction {
  const InvestmentTransaction({
    this.id,
    required this.assetId,
    required this.type,
    required this.quantity,
    required this.price,
    this.fee = 0,
    this.tax = 0,
    required this.transactionDate,
    this.notes,
    this.realizedProfit = 0,
  });

  final int? id;
  final int assetId;
  /// BUY, SELL, DIVIDEND, INTEREST, COUPON
  final String type;
  final double quantity;
  final double price;
  final double fee;
  final double tax;
  final DateTime transactionDate;
  final String? notes;
  final double realizedProfit;

  double get grossValue => quantity * price;
  double get netValue => grossValue + fee + tax;

  factory InvestmentTransaction.fromMap(Map<String, Object?> map) => InvestmentTransaction(
        id: map['id'] as int?,
        assetId: map['asset_id'] as int,
        type: map['type'] as String,
        quantity: (map['quantity'] as num).toDouble(),
        price: (map['price'] as num).toDouble(),
        fee: (map['fee'] as num?)?.toDouble() ?? 0,
        tax: (map['tax'] as num?)?.toDouble() ?? 0,
        transactionDate: DateTime.parse(map['transaction_date'] as String),
        notes: map['notes'] as String?,
        realizedProfit: (map['realized_profit'] as num?)?.toDouble() ?? 0,
      );
}
