import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:sqflite/sqflite.dart';

import '../database/database_service.dart';

class BackupService {
  BackupService._();
  static final BackupService instance = BackupService._();

  static const String appIdentifier = 'com.asetku.v2.asetku';
  static const int schemaVersion = 5;

  static const List<String> _tables = [
    'assets',
    'transactions',
    'price_history',
    'asset_market_links',
    'asset_market_prices',
    'exchange_rates',
  ];

  Future<Map<String, dynamic>> _buildBackup() async {
    final db = await DatabaseService.instance.database;
    final data = <String, dynamic>{};
    for (final table in _tables) {
      data[table] = await db.query(table);
    }
    return {
      'app_identifier': appIdentifier,
      'backup_format': 1,
      'schema_version': schemaVersion,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'tables': data,
    };
  }

  Future<File> createBackupFile({bool automatic = false}) async {
    final payload = await _buildBackup();
    final directory = await getApplicationDocumentsDirectory();
    final backupDirectory = Directory(p.join(directory.path, 'asetku_backups'));
    if (!await backupDirectory.exists()) {
      await backupDirectory.create(recursive: true);
    }
    final timestamp = DateTime.now()
        .toIso8601String()
        .replaceAll(':', '-')
        .replaceAll('.', '-');
    final prefix = automatic ? 'asetku_auto_backup' : 'asetku_backup';
    final file = File(p.join(backupDirectory.path, '${prefix}_$timestamp.json'));
    await file.writeAsString(
      const JsonEncoder.withIndent('  ').convert(payload),
      flush: true,
    );
    return file;
  }

  Future<void> exportAndShare() async {
    final file = await createBackupFile();
    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/json')],
      subject: 'Backup data Asetku',
      text: 'File backup data Asetku. Simpan file ini di tempat yang aman.',
    );
  }

  Future<File?> pickBackupFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return null;
    final picked = result.files.single;
    if (picked.path != null) return File(picked.path!);
    final bytes = picked.bytes;
    if (bytes == null) {
      throw const FormatException('Isi file backup tidak dapat dibaca.');
    }
    final temp = await getTemporaryDirectory();
    final staged = File(p.join(temp.path, 'asetku_import_${DateTime.now().microsecondsSinceEpoch}.json'));
    await staged.writeAsBytes(bytes, flush: true);
    return staged;
  }

  Future<void> validateBackupFile(File file) async {
    final decoded = jsonDecode(await file.readAsString());
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Format file backup tidak valid.');
    }
    _validateBackup(decoded);
  }

  Future<String> restoreFromFile(File file) async {
    final decoded = jsonDecode(await file.readAsString());
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Format file backup tidak valid.');
    }
    _validateBackup(decoded);

    // Keep a recoverable copy of the current database before replacing data.
    await createBackupFile(automatic: true);

    final tableData = decoded['tables'] as Map<String, dynamic>;
    final db = await DatabaseService.instance.database;
    await db.transaction((txn) async {
      // Delete dependent rows first to respect foreign-key constraints.
      for (final table in _tables.reversed) {
        await txn.delete(table);
      }

      // Restore parent rows before their dependent rows.
      for (final table in _tables) {
        final rows = tableData[table] as List<dynamic>;
        for (final row in rows) {
          if (row is! Map<String, dynamic>) {
            throw FormatException('Data tabel $table tidak valid.');
          }
          await txn.insert(
            table,
            Map<String, Object?>.from(row),
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
      }
    });
    return 'Data berhasil dipulihkan. Salinan data sebelum pemulihan juga telah dibuat.';
  }

  void _validateBackup(Map<String, dynamic> backup) {
    if (backup['app_identifier'] != appIdentifier) {
      throw const FormatException(
        'File ini bukan backup dari aplikasi Asetku yang sesuai.',
      );
    }
    if (backup['backup_format'] != 1 ||
        backup['schema_version'] != schemaVersion) {
      throw const FormatException(
        'Versi format backup tidak cocok dengan versi aplikasi ini.',
      );
    }
    final tables = backup['tables'];
    if (tables is! Map<String, dynamic>) {
      throw const FormatException('Bagian data tabel tidak ditemukan.');
    }
    for (final table in _tables) {
      if (tables[table] is! List) {
        throw FormatException('Data tabel $table tidak ditemukan atau rusak.');
      }
    }
  }
}
