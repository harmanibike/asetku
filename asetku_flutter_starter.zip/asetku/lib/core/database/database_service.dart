import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../../models/asset.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, 'asetku.db');
    _database = await openDatabase(
      path,
      version: 5,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute('''CREATE TABLE asset_market_links (asset_id INTEGER PRIMARY KEY, provider TEXT NOT NULL, product_id TEXT NOT NULL, product_name TEXT NOT NULL, nav_date TEXT, updated_at TEXT, FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE)''');
        }
        if (oldVersion < 3) {
          await db.execute('''CREATE TABLE asset_market_prices (asset_id INTEGER PRIMARY KEY, provider TEXT NOT NULL, price_type TEXT NOT NULL, price REAL NOT NULL, source_label TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE)''');
        }
        if (oldVersion < 4) {
          await db.execute('''CREATE TABLE exchange_rates (currency TEXT PRIMARY KEY, rate_to_idr REAL NOT NULL, source_label TEXT NOT NULL, updated_at TEXT NOT NULL)''');
        }
        if (oldVersion < 5) {
          await db.execute('ALTER TABLE transactions ADD COLUMN realized_profit REAL NOT NULL DEFAULT 0');
        }
      },
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            symbol TEXT,
            currency TEXT NOT NULL DEFAULT 'IDR',
            quantity REAL NOT NULL DEFAULT 0,
            average_buy_price REAL NOT NULL DEFAULT 0,
            current_price REAL NOT NULL DEFAULT 0,
            notes TEXT,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            quantity REAL NOT NULL,
            price REAL NOT NULL,
            fee REAL NOT NULL DEFAULT 0,
            tax REAL NOT NULL DEFAULT 0,
            transaction_date TEXT NOT NULL,
            notes TEXT,
            realized_profit REAL NOT NULL DEFAULT 0,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
          )
        ''');
        await db.execute('''
          CREATE TABLE price_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            price REAL NOT NULL,
            recorded_at TEXT NOT NULL,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
          )
        ''');
        await db.execute('''CREATE TABLE asset_market_links (asset_id INTEGER PRIMARY KEY, provider TEXT NOT NULL, product_id TEXT NOT NULL, product_name TEXT NOT NULL, nav_date TEXT, updated_at TEXT, FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE)''');
        await db.execute('''CREATE TABLE asset_market_prices (asset_id INTEGER PRIMARY KEY, provider TEXT NOT NULL, price_type TEXT NOT NULL, price REAL NOT NULL, source_label TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE)''');
        await db.execute('''CREATE TABLE exchange_rates (currency TEXT PRIMARY KEY, rate_to_idr REAL NOT NULL, source_label TEXT NOT NULL, updated_at TEXT NOT NULL)''');
        await db.execute('CREATE INDEX idx_assets_category ON assets(category)');
        await db.execute('CREATE INDEX idx_transactions_asset ON transactions(asset_id)');
      },
    );
    return _database!;
  }

  /// Closes the active database connection. The next database access reopens it.
  Future<void> closeDatabase() async {
    final current = _database;
    _database = null;
    if (current != null && current.isOpen) {
      await current.close();
    }
  }

  Future<List<Asset>> getAssets() async {
    final db = await database;
    final rows = await db.query('assets', orderBy: 'name COLLATE NOCASE ASC');
    return rows.map(Asset.fromMap).toList(growable: false);
  }

  Future<int> saveAsset(Asset asset) async {
    final db = await database;
    final values = asset.toMap()..remove('id');
    if (asset.id == null) {
      return db.insert('assets', values);
    }
    await db.update('assets', values, where: 'id = ?', whereArgs: [asset.id]);
    return asset.id!;
  }

  Future<void> linkMutualFund({required int assetId, required String fundId, required String fundName}) async {
    final db = await database;
    await db.insert('asset_market_links', {'asset_id': assetId, 'provider': 'ReksadanaID', 'product_id': fundId, 'product_name': fundName}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Map<String, Object?>>> getLinkedFunds() async {
    final db = await database;
    return db.rawQuery('''SELECT l.*, a.name AS asset_name, a.quantity, a.current_price FROM asset_market_links l JOIN assets a ON a.id = l.asset_id ORDER BY a.name COLLATE NOCASE''');
  }

  Future<void> updateFundNav({required int assetId, required double nav, required String navDate, required String updatedAt}) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.update('assets', {'current_price': nav}, where: 'id = ?', whereArgs: [assetId]);
      await txn.update('asset_market_links', {'nav_date': navDate, 'updated_at': updatedAt}, where: 'asset_id = ?', whereArgs: [assetId]);
      await txn.insert('price_history', {'asset_id': assetId, 'price': nav, 'recorded_at': updatedAt});
    });
  }


  Future<void> saveGoldMarketPrice({
    required int assetId,
    required String provider,
    required String priceType,
    required double price,
    required String sourceLabel,
    required String updatedAt,
  }) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.update('assets', {'current_price': price}, where: 'id = ?', whereArgs: [assetId]);
      await txn.insert('asset_market_prices', {
        'asset_id': assetId,
        'provider': provider,
        'price_type': priceType,
        'price': price,
        'source_label': sourceLabel,
        'updated_at': updatedAt,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
      await txn.insert('price_history', {
        'asset_id': assetId,
        'price': price,
        'recorded_at': updatedAt,
      });
    });
  }

  Future<List<Map<String, Object?>>> getGoldMarketPrices() async {
    final db = await database;
    return db.rawQuery('''SELECT p.*, a.name AS asset_name, a.quantity, a.currency FROM asset_market_prices p JOIN assets a ON a.id = p.asset_id ORDER BY p.updated_at DESC''');
  }

  Future<Map<String, Map<String, Object?>>> getExchangeRates() async {
    final db = await database;
    final rows = await db.query('exchange_rates');
    return {for (final row in rows) row['currency'].toString(): row};
  }

  Future<void> saveExchangeRate({
    required String currency,
    required double rateToIdr,
    required String sourceLabel,
    required String updatedAt,
  }) async {
    final db = await database;
    await db.insert(
      'exchange_rates',
      {
        'currency': currency.toUpperCase(),
        'rate_to_idr': rateToIdr,
        'source_label': sourceLabel,
        'updated_at': updatedAt,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> deleteExchangeRate(String currency) async {
    final db = await database;
    return db.delete('exchange_rates', where: 'currency = ?', whereArgs: [currency.toUpperCase()]);
  }

  Future<List<Map<String, Object?>>> getTransactions(int assetId) async {
    final db = await database;
    return db.query('transactions', where: 'asset_id = ?', whereArgs: [assetId], orderBy: 'transaction_date DESC, id DESC');
  }

  Future<void> addInvestmentTransaction({
    required int assetId,
    required String type,
    required double quantity,
    required double price,
    required double fee,
    required double tax,
    required DateTime transactionDate,
    String? notes,
  }) async {
    final db = await database;
    await db.transaction((txn) async {
      final rows = await txn.query('assets', where: 'id = ?', whereArgs: [assetId], limit: 1);
      if (rows.isEmpty) throw Exception('Aset tidak ditemukan.');
      final asset = rows.first;
      final oldQty = (asset['quantity'] as num).toDouble();
      final oldAvg = (asset['average_buy_price'] as num).toDouble();
      var newQty = oldQty;
      var newAvg = oldAvg;
      var realized = 0.0;
      final gross = quantity * price;
      if (type == 'BUY') {
        if (quantity <= 0) throw Exception('Jumlah pembelian harus lebih dari nol.');
        newQty = oldQty + quantity;
        newAvg = ((oldQty * oldAvg) + gross + fee + tax) / newQty;
      } else if (type == 'SELL') {
        if (quantity <= 0 || quantity > oldQty) throw Exception('Jumlah penjualan melebihi unit yang dimiliki.');
        realized = gross - fee - tax - (quantity * oldAvg);
        newQty = oldQty - quantity;
        if (newQty.abs() < 0.0000001) newQty = 0;
        if (newQty == 0) newAvg = 0;
      } else if (!['DIVIDEND', 'INTEREST', 'COUPON'].contains(type)) {
        throw Exception('Jenis transaksi tidak dikenal.');
      }
      await txn.insert('transactions', {
        'asset_id': assetId,
        'type': type,
        'quantity': quantity,
        'price': price,
        'fee': fee,
        'tax': tax,
        'transaction_date': transactionDate.toIso8601String(),
        'notes': notes,
        'realized_profit': realized,
      });
      if (type == 'BUY' || type == 'SELL') {
        await txn.update('assets', {
          'quantity': newQty,
          'average_buy_price': newAvg,
        }, where: 'id = ?', whereArgs: [assetId]);
      }
    });
  }

  Future<double> getRealizedProfit(int assetId) async {
    final db = await database;
    final rows = await db.rawQuery('SELECT COALESCE(SUM(realized_profit), 0) AS total FROM transactions WHERE asset_id = ?', [assetId]);
    return (rows.first['total'] as num).toDouble();
  }

  Future<int> deleteAsset(int id) async {
    final db = await database;
    return db.delete('assets', where: 'id = ?', whereArgs: [id]);
  }
}
