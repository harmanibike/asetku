import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../../models/asset.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final dbPath = await getDatabasesPath();
    final path = p.join(dbPath, 'asetku.db');
    _database = await openDatabase(
      path,
      version: 1,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            symbol TEXT,
            currency TEXT NOT NULL DEFAULT 'IDR',
            quantity REAL NOT NULL DEFAULT 0,
            average_buy_price REAL NOT NULL DEFAULT 0,
            current_price REAL NOT NULL DEFAULT 0,
            notes TEXT,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            quantity REAL NOT NULL,
            price REAL NOT NULL,
            fee REAL NOT NULL DEFAULT 0,
            tax REAL NOT NULL DEFAULT 0,
            transaction_date TEXT NOT NULL,
            notes TEXT,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
          )
        ''');
        await db.execute('''
          CREATE TABLE price_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            asset_id INTEGER NOT NULL,
            price REAL NOT NULL,
            recorded_at TEXT NOT NULL,
            FOREIGN KEY(asset_id) REFERENCES assets(id) ON DELETE CASCADE
          )
        ''');
        await db.execute('CREATE INDEX idx_assets_category ON assets(category)');
        await db.execute('CREATE INDEX idx_transactions_asset ON transactions(asset_id)');
      },
    );
    return _database!;
  }

  Future<List<Asset>> getAssets() async {
    final db = await database;
    final rows = await db.query('assets', orderBy: 'name COLLATE NOCASE ASC');
    return rows.map(Asset.fromMap).toList(growable: false);
  }

  Future<int> saveAsset(Asset asset) async {
    final db = await database;
    final values = asset.toMap()..remove('id');
    if (asset.id == null) {
      return db.insert('assets', values);
    }
    await db.update('assets', values, where: 'id = ?', whereArgs: [asset.id]);
    return asset.id!;
  }

  Future<int> deleteAsset(int id) async {
    final db = await database;
    return db.delete('assets', where: 'id = ?', whereArgs: [id]);
  }
}
