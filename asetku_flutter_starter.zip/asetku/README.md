# Asetku

Aplikasi Android Flutter untuk melacak investasi dan seluruh kekayaan pribadi.

## Fitur fondasi saat ini
- Dashboard rancangan awal.
- Tema modern Material 3.
- Database SQLite lokal dengan tabel assets, transactions, dan price_history.
- Model aset dan transaksi dasar.
- Format mata uang Rupiah.

## Menjalankan proyek
1. Ekstrak folder proyek.
2. Pastikan Flutter SDK dan Android SDK sudah terpasang.
3. Jalankan `flutter pub get`.
4. Jalankan `flutter run`.

## Catatan
Angka pada dashboard saat ini adalah data ilustrasi antarmuka, bukan portofolio sungguhan.
Database sudah disiapkan, tetapi layar CRUD dan perhitungan portofolio akan dibangun pada tahap berikutnya.

## Identitas Android
Gunakan applicationId dan namespace `com.asetku.app` pada konfigurasi Android.


## Pembaruan harga reksadana (Tahap 4 awal)
- Data katalog dan NAB terbaru diambil dari API publik ReksadanaID (`https://reksadana.risanb.com/api/funds.json`).
- Hubungkan satu aset berkategori Reksadana dengan ID produk ReksadanaID melalui menu Harga Pasar di dashboard.
- Pembaruan NAB mengubah `current_price` saja; `average_buy_price` dan jumlah unit tidak diubah.
- Setiap pembaruan disimpan ke tabel `price_history`; metadata tautan dan tanggal NAB disimpan pada `asset_market_links`.
- NAB mengikuti ketersediaan data sumber (umumnya hari bursa), bukan harga real-time.
- API publik bersifat read-only dan tanpa API key; aplikasi tetap membutuhkan koneksi internet.
