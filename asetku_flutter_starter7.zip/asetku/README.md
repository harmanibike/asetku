# Asetku

Aplikasi Android Flutter untuk melacak investasi dan seluruh kekayaan pribadi.

## Fitur fondasi saat ini
- Dashboard rancangan awal.
- Tema modern Material 3.
- Database SQLite lokal dengan tabel assets, transactions, dan price_history.
- Model aset dan transaksi dasar.
- Format mata uang Rupiah.

## Menjalankan proyek
1. Ekstrak folder proyek.
2. Pastikan Flutter SDK dan Android SDK sudah terpasang.
3. Jalankan `flutter pub get`.
4. Jalankan `flutter run`.

## Catatan
Angka pada dashboard saat ini adalah data ilustrasi antarmuka, bukan portofolio sungguhan.
Database sudah disiapkan, tetapi layar CRUD dan perhitungan portofolio akan dibangun pada tahap berikutnya.

## Identitas Android
Gunakan applicationId dan namespace `com.asetku.app` pada konfigurasi Android.


## Pembaruan harga reksadana (Tahap 4 awal)
- Data katalog dan NAB terbaru diambil dari API publik ReksadanaID (`https://reksadana.risanb.com/api/funds.json`).
- Hubungkan satu aset berkategori Reksadana dengan ID produk ReksadanaID melalui menu Harga Pasar di dashboard.
- Pembaruan NAB mengubah `current_price` saja; `average_buy_price` dan jumlah unit tidak diubah.
- Setiap pembaruan disimpan ke tabel `price_history`; metadata tautan dan tanggal NAB disimpan pada `asset_market_links`.
- NAB mengikuti ketersediaan data sumber (umumnya hari bursa), bukan harga real-time.
- API publik bersifat read-only dan tanpa API key; aplikasi tetap membutuhkan koneksi internet.

## Tahap 5 — Harga pasar
- NAB reksadana diambil dari katalog ReksadanaID dan dapat diperbarui dari layar Harga Pasar.
- Harga emas/emas digital dapat dicatat per penyedia (Treasury, Pegadaian, Pluang, IndoGold, Antam, UBS, Galeri 24, atau lainnya).
- Harga emas yang dicatat memperbarui `current_price` dan menambahkan catatan `price_history`; `average_buy_price` dan transaksi historis tidak diubah.
- Untuk sementara, harga emas dimasukkan berdasarkan angka buyback yang terlihat pada kanal resmi penyedia. Integrasi otomatis hanya akan ditambahkan setelah endpoint/sumber data resmi dapat diverifikasi.


## Tahap 6 — Kurs Mata Uang
- Menambahkan tabel `exchange_rates` melalui migrasi database versi 4.
- Pengguna dapat menyimpan kurs USD, SGD, EUR, MYR, dan JPY ke IDR.
- Dashboard mengonversi modal dan nilai pasar ke IDR hanya jika kurs tersedia.
- Kurs belum otomatis; tidak ada angka kurs bawaan yang ditebak.
- Perubahan kurs tidak mengubah harga beli rata-rata maupun riwayat transaksi.

## Tahap 7 — Transaksi investasi
- Menambahkan riwayat transaksi per aset: beli, jual, dividen, bunga, dan kupon obligasi.
- Pembelian memperbarui jumlah unit dan harga pokok rata-rata tertimbang, termasuk biaya dan pajak.
- Penjualan memvalidasi agar unit yang dijual tidak melebihi kepemilikan, mengurangi jumlah unit, dan mencatat laba/rugi terealisasi.
- Dividen, bunga, dan kupon dicatat sebagai pendapatan tanpa mengubah jumlah unit.
- Migrasi database versi 5 menambahkan kolom laba/rugi terealisasi; data transaksi lama tetap dipertahankan.
- Riwayat transaksi tidak mengubah harga pasar terakhir maupun histori harga pasar.
